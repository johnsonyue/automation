docker rm -f `docker ps -a -q`

docker network rm `docker network ls | grep net_` 

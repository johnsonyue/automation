#!/bin/bash

hostInfo="host-asinfo.ip_level"
absolute_path="/home/yupeng/quagga"
shared="shared"

asInfo="conf/node-list-1"
asLink="conf/link-list-1"
conf="conf"

echo ">> remove"
./remove.sh
echo ">> create"
mkdir -p $absolute_path

cp $shared/* $absolute_path

python gen-bgp.py $asInfo $asLink 
# output file: $asInfo.ip_level $asLink.ip_level

python gen-bgp-conf.py $asInfo.ip_level $asLink.ip_level
# output file: bgp-configure.txt

cp ./bgp-configure.txt $absolute_path
mv ./bgp-configure.txt $conf


python split-to-host.py ${conf}/hostip-hostid.txt ${conf}/hostid-as.txt $asInfo.ip_level
# output file: host-asinfo.ip_level

mv $hostInfo $conf



# put get-host-ip-address.sh and get_ip in current directory
python gen-container.py ${conf}/$hostInfo $asLink.ip_level ${conf}/bgp-configure.txt

# generate interlink for openvswitch
python gen-interlink.py ${conf}/$hostInfo ${asLink}.ip_level > ${conf}/interlink.txt

rm -f host-ip-address 

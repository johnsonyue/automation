import os
import sys

f = open(sys.argv[1], 'r')

confLines = f.readlines()

for i in range(len(confLines)):
	confLines[i] = confLines[i].strip()
f.close()


# get container hostname

hostname = (os.popen("hostname")).readlines()[0][:-1]

container_name = ".".join(hostname.split("-"))

# print "containerName: ", container_name


fw_zebra = open("/etc/quagga/zebra.conf", 'w')
fw_bgpd = open("/etc/quagga/bgpd.conf", 'w')

i = 1
while i < len(confLines):


	if str(confLines[i]) != str(container_name):

#		print confLines[i], container_name
		i += 1
		continue

	zebra_line = i + 2
	while confLines[zebra_line] != "####":
			
		fw_zebra.writelines(confLines[zebra_line] + "\n")
		zebra_line += 1
		
	bgp_line = zebra_line + 2

	while confLines[bgp_line] != "####":

                fw_bgpd.writelines(confLines[bgp_line] + "\n")
                bgp_line += 1
	break
	i += 1

if i >= len(confLines):
	print "container_name not found"

fw_zebra.close()
fw_bgpd.close()


os.system("service zebra start")
os.system("service bgpd start")
